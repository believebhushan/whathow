import styled, { css } from 'styled-components';

export  const Row =styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  border: 1px solid darkcyan;
  

`;
export  const ListContacts =styled.div`
  height: 1000px;
   width: auto;
  margin-bottom: 10px;
  overflow:scroll;
-webkit-overflow-scrolling: touch;
    overflow-y: scroll;
    flex: 1;
    color: #cf0204;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
    background-color: #fff;

`;

