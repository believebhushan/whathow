
const envVariables=   {"domain":"http://localhost:7003"};
export default envVariables;