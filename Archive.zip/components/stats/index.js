import React from 'react';
import CSVReader from '../bulkwithfiles';

const  Stats =(props) =>{
    return (
        <>
            Stats Here
            <CSVReader></CSVReader>
        </>
    );
}

export default Stats;