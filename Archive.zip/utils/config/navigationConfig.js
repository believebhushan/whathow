

const navigationData={
    type:"direct use",
    options:[
        {name:"Send Bulk Messages",value:"sendBM"},
        {name:"Send to Your Contacts",value:"sendBMC"},
        {name:"Send  Bulk Documents",value:"sendBMM"},
        {name:"Stats",value:"STATS"},
    ]
    
}
export default navigationData;