const domain="http://whatui.biharapp.com";
export default domain;